<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Isi Presensi - Portal Akademik PeTIK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; }
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #145a32, #1e8449);
            width: 250px;
            position: fixed;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 10px;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .main-content { margin-left: 250px; padding: 30px; }
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }
        .status-btn { cursor: pointer; }
        .status-btn input[type="radio"] { display: none; }
        .status-btn label {
            padding: 6px 14px;
            border-radius: 6px;
            border: 2px solid #dee2e6;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.2s;
        }
        .status-btn input[type="radio"]:checked + label {
            font-weight: bold;
            border-color: currentColor;
        }
        .btn-present input:checked + label { background: #d1f0d1; color: #1e8449; border-color: #1e8449; }
        .btn-absent input:checked + label { background: #f8d7da; color: #dc3545; border-color: #dc3545; }
        .btn-sick input:checked + label { background: #fff3cd; color: #ffc107; border-color: #ffc107; }
        .btn-permission input:checked + label { background: #cce5ff; color: #2E75B6; border-color: #2E75B6; }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3">
        <div class="text-center mb-4 mt-2">
            <h5 class="text-white fw-bold">Portal Akademik</h5>
            <small class="text-white-50">PeTIK Jombang</small>
        </div>
        <hr class="text-white">
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('lecturer.dashboard') }}" class="nav-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="bi bi-calendar3 me-2"></i> Jadwal Mengajar
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.attendances.index') }}" class="nav-link active">
                    <i class="bi bi-clipboard-check me-2"></i> Presensi
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="bi bi-journal-richtext me-2"></i> Input Nilai
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="bi bi-file-earmark-text me-2"></i> Materi
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="bi bi-megaphone me-2"></i> Pengumuman
                </a>
            </li>
        </ul>
        <div class="mt-auto">
            <hr class="text-white">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link btn btn-link text-start w-100">
                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-bold mb-0">Isi Presensi</h4>
                <small class="text-muted">{{ $schedule->course->name }} — {{ $date }}</small>
            </div>
            <a href="{{ route('lecturer.attendances.index') }}" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i> Kembali
            </a>
        </div>

        <!-- Info Jadwal -->
        <div class="card p-3 mb-4">
            <div class="row g-3">
                <div class="col-md-3">
                    <small class="text-muted d-block">Mata Kuliah</small>
                    <strong>{{ $schedule->course->name }}</strong>
                </div>
                <div class="col-md-3">
                    <small class="text-muted d-block">Tanggal</small>
                    <strong>{{ \Carbon\Carbon::parse($date)->format('d F Y') }}</strong>
                </div>
                <div class="col-md-3">
                    <small class="text-muted d-block">Ruangan</small>
                    <strong>{{ $schedule->room ?? '-' }}</strong>
                </div>
                <div class="col-md-3">
                    <small class="text-muted d-block">Total Mahasantri</small>
                    <strong>{{ $students->count() }} orang</strong>
                </div>
            </div>
        </div>

        <form action="{{ route('lecturer.attendances.store') }}" method="POST">
            @csrf
            <input type="hidden" name="schedule_id" value="{{ $schedule->id }}">
            <input type="hidden" name="date" value="{{ $date }}">

            <div class="card">
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">No</th>
                                <th>NIM</th>
                                <th>Nama</th>
                                <th>Status Kehadiran</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($students as $index => $student)
                            @php $existing = $existingAttendances[$student->id] ?? null; @endphp
                            <tr>
                                <td class="ps-4">{{ $index + 1 }}</td>
                                <td>{{ $student->nim }}</td>
                                <td>{{ $student->name }}</td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <div class="status-btn btn-present">
                                            <input type="radio" name="attendance[{{ $student->id }}]" id="present_{{ $student->id }}" value="present" {{ ($existing && $existing->status == 'present') || !$existing ? 'checked' : '' }}>
                                            <label for="present_{{ $student->id }}">Hadir</label>
                                        </div>
                                        <div class="status-btn btn-absent">
                                            <input type="radio" name="attendance[{{ $student->id }}]" id="absent_{{ $student->id }}" value="absent" {{ $existing && $existing->status == 'absent' ? 'checked' : '' }}>
                                            <label for="absent_{{ $student->id }}">Absen</label>
                                        </div>
                                        <div class="status-btn btn-sick">
                                            <input type="radio" name="attendance[{{ $student->id }}]" id="sick_{{ $student->id }}" value="sick" {{ $existing && $existing->status == 'sick' ? 'checked' : '' }}>
                                            <label for="sick_{{ $student->id }}">Sakit</label>
                                        </div>
                                        <div class="status-btn btn-permission">
                                            <input type="radio" name="attendance[{{ $student->id }}]" id="permission_{{ $student->id }}" value="permission" {{ $existing && $existing->status == 'permission' ? 'checked' : '' }}>
                                            <label for="permission_{{ $student->id }}">Izin</label>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <input type="text" name="notes[{{ $student->id }}]" class="form-control form-control-sm" value="{{ $existing ? $existing->notes : '' }}" placeholder="Keterangan (opsional)">
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">
                                    <i class="bi bi-inbox fs-4 d-block mb-2"></i>
                                    Belum ada data mahasantri
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            @if($students->count() > 0)
            <div class="mt-4">
                <button type="submit" class="btn btn-success px-4">
                    <i class="bi bi-save me-2"></i> Simpan Presensi
                </button>
                <a href="{{ route('lecturer.attendances.index') }}" class="btn btn-outline-secondary ms-2">Batal</a>
            </div>
            @endif
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>