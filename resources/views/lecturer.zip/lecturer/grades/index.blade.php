<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Nilai - Portal Akademik PeTIK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; }
        
        /* Sidebar Styling & Responsiveness */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #145a32, #1e8449);
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1040;
            transition: transform 0.3s ease;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 10px;
        }
        
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        /* Main Content Layout */
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
            transition: margin-left 0.3s ease;
        }
        
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }

        /* Responsive Breakpoints (Mobile & Tablet) */
        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: 80px; /* Space agar konten tidak tertutup top navbar mobile */
            }
        }
    </style>
</head>
<body>

    <!-- Mobile Top Navbar (Hanya muncul di Layar Handphone/Tablet) -->
    <nav class="navbar navbar-dark bg-success fixed-top d-lg-none shadow-sm px-3">
        <button class="navbar-toggler" type="button" id="sidebarToggle" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <span class="navbar-brand mb-0 h1 fs-6 fw-bold">Portal Akademik PeTIK</span>
    </nav>

    <!-- Sidebar Backdrop -->
    <div class="modal-backdrop fade show d-none" id="sidebarBackdrop" style="z-index: 1030;"></div>

    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3" id="sidebarMenu">
        <!-- Close Button Mobile -->
        <div class="d-flex justify-content-end d-lg-none">
            <button type="button" class="btn-close btn-close-white" id="sidebarClose" aria-label="Close"></button>
        </div>
        
        <div class="text-center mb-4 mt-2">
            <h5 class="text-white fw-bold">Portal Akademik</h5>
            <small class="text-white-50">PeTIK Jombang</small>
        </div>
        <hr class="text-white">
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('lecturer.dashboard') }}" class="nav-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.schedules.index') }}" class="nav-link">
                    <i class="bi bi-calendar3 me-2"></i> Jadwal Mengajar
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.attendances.index') }}" class="nav-link">
                    <i class="bi bi-clipboard-check me-2"></i> Presensi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.grades.index') }}" class="nav-link active">
                    <i class="bi bi-journal-richtext me-2"></i> Input Nilai
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.materials.index') }}" class="nav-link">
                    <i class="bi bi-file-earmark-text me-2"></i> Materi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.announcements.index') }}" class="nav-link">
                    <i class="bi bi-megaphone me-2"></i> Pengumuman
                </a>
            </li>
        </ul>
        <div class="mt-auto">
            <hr class="text-white">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link btn btn-link text-start w-100">
                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h4 class="fw-bold mb-0">Input Nilai</h4>
                <small class="text-muted">Pilih jadwal untuk menginput nilai</small>
            </div>
        </div>

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="row g-4">
            @forelse($schedules as $schedule)
            <div class="col-xl-4 col-md-6 col-12">
                <div class="card p-4 h-100 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-success bg-opacity-10 p-3 rounded-circle me-3">
                                <i class="bi bi-journal-richtext text-success fs-5"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold mb-0">{{ $schedule->course->name }}</h6>
                                <small class="text-muted">{{ $schedule->course->code }}</small>
                            </div>
                        </div>
                        <div class="mb-4">
                            <small class="text-muted d-block mb-1"><i class="bi bi-layers me-2 text-success"></i> {{ $schedule->course->credits }} SKS</small>
                            <small class="text-muted d-block mb-1"><i class="bi bi-mortarboard me-2 text-success"></i> Semester {{ $schedule->semester }}</small>
                            <small class="text-muted d-block"><i class="bi bi-calendar me-2 text-success"></i> TA {{ $schedule->academic_year }}/{{ $schedule->academic_year + 1 }}</small>
                        </div>
                    </div>
                    <a href="{{ route('lecturer.grades.create', ['schedule_id' => $schedule->id]) }}" class="btn btn-success btn-sm w-100 py-2 mt-auto">
                        <i class="bi bi-pencil-square me-2"></i> Input Nilai
                    </a>
                </div>
            </div>
            @empty
            <div class="col-12">
                <div class="card p-5 text-center text-muted">
                    <i class="bi bi-inbox fs-1 d-block mb-3 text-success"></i>
                    <p class="mb-0">Belum ada jadwal mengajar</p>
                </div>
            </div>
            @endforelse
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript Logic untuk Toggle Buka/Tutup Sidebar Mobile
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebarClose = document.getElementById('sidebarClose');
        const sidebarMenu = document.getElementById('sidebarMenu');
        const sidebarBackdrop = document.getElementById('sidebarBackdrop');

        function toggleSidebar() {
            sidebarMenu.classList.toggle('show');
            sidebarBackdrop.classList.toggle('d-none');
        }

        sidebarToggle.addEventListener('click', toggleSidebar);
        sidebarClose.addEventListener('click', toggleSidebar);
        sidebarBackdrop.addEventListener('click', toggleSidebar);
    </script>
</body>
</html>