<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengumuman - Portal Akademik PeTIK</title>
    <link rel="icon" href="data:,">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; }
        
        /* Sidebar Styling & Responsiveness */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #145a32, #1e8449);
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1040;
            transition: transform 0.3s ease;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 10px;
        }
        
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        /* Main Content Layout */
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
            transition: margin-left 0.3s ease;
        }
        
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }

        /* Responsive Breakpoints (Mobile & Tablet) */
        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: 80px; /* Space agar tidak tertutup navbar atas */
            }
        }
    </style>
</head>
<body>

    <!-- Mobile Top Navbar (Hanya muncul di HP/Tablet) -->
    <nav class="navbar navbar-dark bg-success fixed-top d-lg-none shadow-sm px-3">
        <button class="navbar-toggler" type="button" id="sidebarToggle" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <span class="navbar-brand mb-0 h1 fs-6 fw-bold">Portal Akademik PeTIK</span>
    </nav>

    <!-- Sidebar Backdrop -->
    <div class="modal-backdrop fade show d-none" id="sidebarBackdrop" style="z-index: 1030;"></div>

    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3" id="sidebarMenu">
        <!-- Close Button Mobile -->
        <div class="d-flex justify-content-end d-lg-none">
            <button type="button" class="btn-close btn-close-white" id="btnSidebarClose" aria-label="Close"></button>
        </div>
        
        <div class="text-center mb-4 mt-2">
            <h5 class="text-white fw-bold">Portal Akademik</h5>
            <small class="text-white-50">PeTIK Jombang</small>
        </div>
        <hr class="text-white">
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('lecturer.dashboard') }}" class="nav-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.schedules.index') }}" class="nav-link">
                    <i class="bi bi-calendar3 me-2"></i> Jadwal Mengajar
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.attendances.index') }}" class="nav-link">
                    <i class="bi bi-clipboard-check me-2"></i> Presensi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.grades.index') }}" class="nav-link">
                    <i class="bi bi-journal-richtext me-2"></i> Input Nilai
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.materials.index') }}" class="nav-link">
                    <i class="bi bi-file-earmark-text me-2"></i> Materi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.announcements.index') }}" class="nav-link active">
                    <i class="bi bi-megaphone me-2"></i> Pengumuman
                </a>
            </li>
        </ul>
        <div class="mt-auto">
            <hr class="text-white">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link btn btn-link text-start w-100">
                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header Section -->
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3 mb-4">
            <div class="d-flex align-items-center gap-3">
                <div>
                    <h4 class="fw-bold mb-0">Pengumuman</h4>
                    <small class="text-muted">Kelola pengumuman untuk mahasantri</small>
                </div>
            </div>
            <a href="{{ route('lecturer.announcements.create') }}" class="btn btn-success w-100 w-sm-auto py-2 text-nowrap">
                <i class="bi bi-plus-circle me-2"></i> Tambah Pengumuman
            </a>
        </div>

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <!-- Data Table Card -->
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="min-width: 900px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4" style="width: 6%">No</th>
                                <th style="width: 34%">Judul</th>
                                <th style="width: 15%">Target</th>
                                <th style="width: 15%">Dibuat Oleh</th>
                                <th style="width: 15%">Tanggal</th>
                                <th style="width: 10%">Status</th>
                                <th class="text-center" style="width: 5%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($announcements as $index => $announcement)
                            <tr>
                                <td class="ps-4">{{ $index + 1 }}</td>
                                <td>
                                    <span class="fw-semibold text-dark d-block text-wrap" style="max-width: 320px;">
                                        {{ $announcement->title }}
                                    </span>
                                </td>
                                <td>
                                    @if($announcement->target == 'students')
                                        <span class="badge bg-primary bg-opacity-10 text-primary px-2.5 py-1.5 rounded">
                                            <i class="bi bi-people me-1"></i> Mahasantri
                                        </span>
                                    @else
                                        <span class="badge bg-secondary bg-opacity-10 text-secondary px-2.5 py-1.5 rounded">
                                            {{ $announcement->target }}
                                        </span>
                                    @endif
                                </td>
                                <td class="text-secondary"><i class="bi bi-person me-1"></i> {{ $announcement->user->name }}</td>
                                <td class="text-muted">{{ $announcement->created_at->format('d M Y') }}</td>
                                <td>
                                    @if($announcement->is_published)
                                        <span class="badge bg-success bg-opacity-10 text-success px-2.5 py-1.5 rounded">
                                            <i class="bi bi-check2-circle me-1"></i> Aktif
                                        </span>
                                    @else
                                        <span class="badge bg-secondary bg-opacity-10 text-secondary px-2.5 py-1.5 rounded">
                                            <i class="bi bi-eye-slash me-1"></i> Nonaktif
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center pe-3">
                                        <a href="{{ route('lecturer.announcements.edit', $announcement->id) }}" class="btn btn-sm btn-outline-warning px-2" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form action="{{ route('lecturer.announcements.destroy', $announcement->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus pengumuman ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger px-2" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="bi bi-megaphone fs-1 d-block mb-3 text-success"></i>
                                    Belum ada pengumuman yang diterbitkan.
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Logika Javascript untuk Toggle Buka/Tutup Sidebar Mobile & Backdrop
        const sidebarMenu = document.getElementById('sidebarMenu');
        const sidebarToggleTop = document.getElementById('sidebarToggle');      // Navbar atas mobile
        const btnSidebarToggleMain = document.getElementById('btnSidebarToggle'); // Tombol dekat judul konten
        const btnClose = document.getElementById('btnSidebarClose');
        const sidebarBackdrop = document.getElementById('sidebarBackdrop');

        function openSidebar() {
            sidebarMenu.classList.add('show');
            sidebarBackdrop.classList.remove('d-none');
        }

        function closeSidebar() {
            sidebarMenu.classList.remove('show');
            sidebarBackdrop.classList.add('d-none');
        }

        // Event Listeners untuk membuka sidebar
        if(sidebarToggleTop) sidebarToggleTop.addEventListener('click', openSidebar);
        if(btnSidebarToggleMain) btnSidebarToggleMain.addEventListener('click', openSidebar);
        
        // Event Listeners untuk menutup sidebar
        if(btnClose) btnClose.addEventListener('click', closeSidebar);
        if(sidebarBackdrop) sidebarBackdrop.addEventListener('click', closeSidebar);

        // Reset otomatis sistem penutup jika layar di-resize kembali ke mode desktop
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 992) {
                closeSidebar();
            }
        });
    </script>
</body>
</html>