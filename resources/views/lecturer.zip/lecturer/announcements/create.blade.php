<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengumuman - Portal Akademik PeTIK</title>
    <link rel="icon" href="data:,">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; }
        
        /* Sidebar Styling & Responsiveness */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #145a32, #1e8449);
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1040;
            transition: transform 0.3s ease;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 10px;
        }
        
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        /* Main Content Layout */
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
            transition: margin-left 0.3s ease;
        }
        
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }

        /* Responsive Breakpoints (Mobile & Tablet) */
        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: 80px; /* Space agar tidak tertutup navbar atas */
            }
        }
    </style>
</head>
<body>

    <!-- Mobile Top Navbar (Hanya muncul di HP/Tablet) -->
    <nav class="navbar navbar-dark bg-success fixed-top d-lg-none shadow-sm px-3">
        <button class="navbar-toggler" type="button" id="sidebarToggle" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <span class="navbar-brand mb-0 h1 fs-6 fw-bold">Portal Akademik PeTIK</span>
    </nav>

    <!-- Sidebar Backdrop -->
    <div class="modal-backdrop fade show d-none" id="sidebarBackdrop" style="z-index: 1030;"></div>

    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3" id="sidebarMenu">
        <!-- Close Button Mobile -->
        <div class="d-flex justify-content-end d-lg-none">
            <button type="button" class="btn-close btn-close-white" id="btnSidebarClose" aria-label="Close"></button>
        </div>
        
        <div class="text-center mb-4 mt-2">
            <h5 class="text-white fw-bold">Portal Academic</h5>
            <small class="text-white-50">PeTIK Jombang</small>
        </div>
        <hr class="text-white">
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('lecturer.dashboard') }}" class="nav-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.schedules.index') }}" class="nav-link">
                    <i class="bi bi-calendar3 me-2"></i> Jadwal Mengajar
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.attendances.index') }}" class="nav-link">
                    <i class="bi bi-clipboard-check me-2"></i> Presensi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.grades.index') }}" class="nav-link">
                    <i class="bi bi-journal-richtext me-2"></i> Input Nilai
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.materials.index') }}" class="nav-link">
                    <i class="bi bi-file-earmark-text me-2"></i> Materi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.announcements.index') }}" class="nav-link active">
                    <i class="bi bi-megaphone me-2"></i> Pengumuman
                </a>
            </li>
        </ul>
        <div class="mt-auto">
            <hr class="text-white">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link btn btn-link text-start w-100">
                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4 gap-3">
            <div class="d-flex align-items-center gap-3">
                <div>
                    <h4 class="fw-bold mb-0">Tambah Pengumuman</h4>
                    <small class="text-muted">Buat pengumuman baru</small>
                </div>
            </div>
            <a href="{{ route('lecturer.announcements.index') }}" class="btn btn-outline-secondary text-nowrap">
                <i class="bi bi-arrow-left me-2"></i> Kembali
            </a>
        </div>

        <div class="card p-4 shadow-sm">
            @if($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('lecturer.announcements.store') }}" method="POST">
                @csrf
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label fw-semibold">Judul Pengumuman <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control" value="{{ old('title') }}" placeholder="Masukkan judul pengumuman" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Target <span class="text-danger">*</span></label>
                        <select name="target" class="form-select" required>
                            <option value="">-- Pilih Target --</option>
                            <option value="students" {{ old('target') == 'students' ? 'selected' : '' }}>Mahasantri</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Status</label>
                        <select name="is_published" class="form-select">
                            <option value="1" {{ old('is_published') == '1' ? 'selected' : '' }}>Aktif (Publikasikan)</option>
                            <option value="0" {{ old('is_published') == '0' ? 'selected' : '' }}>Nonaktif (Draf)</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Isi Pengumuman <span class="text-danger">*</span></label>
                        <textarea name="content" class="form-control" rows="6" placeholder="Tulis isi pengumuman di sini..." required>{{ old('content') }}</textarea>
                    </div>
                    <div class="col-12 mt-4">
                        <button type="submit" class="btn btn-primary px-4 me-1">
                            <i class="bi bi-send me-2"></i> Publikasikan
                        </button>
                        <a href="{{ route('lecturer.announcements.index') }}" class="btn btn-outline-secondary px-4">Batal</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Logika Javascript untuk Toggle Buka/Tutup Sidebar Mobile & Backdrop
        const sidebarMenu = document.getElementById('sidebarMenu');
        const sidebarToggleTop = document.getElementById('sidebarToggle');      // Navbar atas mobile
        const btnSidebarToggleMain = document.getElementById('btnSidebarToggle'); // Tombol dekat judul konten
        const btnClose = document.getElementById('btnSidebarClose');
        const sidebarBackdrop = document.getElementById('sidebarBackdrop');

        function openSidebar() {
            sidebarMenu.classList.add('show');
            sidebarBackdrop.classList.remove('d-none');
        }

        function closeSidebar() {
            sidebarMenu.classList.remove('show');
            sidebarBackdrop.classList.add('d-none');
        }

        // Event Listeners untuk membuka sidebar
        if(sidebarToggleTop) sidebarToggleTop.addEventListener('click', openSidebar);
        if(btnSidebarToggleMain) btnSidebarToggleMain.addEventListener('click', openSidebar);
        
        // Event Listeners untuk menutup sidebar
        if(btnClose) btnClose.addEventListener('click', closeSidebar);
        if(sidebarBackdrop) sidebarBackdrop.addEventListener('click', closeSidebar);

        // Reset otomatis sistem penutup jika layar di-resize kembali ke mode desktop
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 992) {
                closeSidebar();
            }
        });
    </script>
</body>
</html>