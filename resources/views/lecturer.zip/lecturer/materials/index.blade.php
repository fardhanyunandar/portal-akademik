<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materi - Portal Akademik PeTIK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; }
        
        /* Sidebar Styling & Responsiveness */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #145a32, #1e8449);
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1040;
            transition: transform 0.3s ease;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 10px;
        }
        
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        /* Main Content Layout */
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
            transition: margin-left 0.3s ease;
        }
        
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }

        /* Responsive Breakpoints (Mobile & Tablet) */
        @media (max-width: 991.98px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
                padding: 20px;
                padding-top: 80px; /* Space agar tidak tertutup navbar atas */
            }
        }
    </style>
</head>
<body>

    <!-- Mobile Top Navbar (Hanya muncul di HP/Tablet) -->
    <nav class="navbar navbar-dark bg-success fixed-top d-lg-none shadow-sm px-3">
        <button class="navbar-toggler" type="button" id="sidebarToggle" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <span class="navbar-brand mb-0 h1 fs-6 fw-bold">Portal Akademik PeTIK</span>
    </nav>

    <!-- Sidebar Backdrop -->
    <div class="modal-backdrop fade show d-none" id="sidebarBackdrop" style="z-index: 1030;"></div>

    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3" id="sidebarMenu">
        <!-- Close Button Mobile -->
        <div class="d-flex justify-content-end d-lg-none">
            <button type="button" class="btn-close btn-close-white" id="sidebarClose" aria-label="Close"></button>
        </div>
        
        <div class="text-center mb-4 mt-2">
            <h5 class="text-white fw-bold">Portal Akademik</h5>
            <small class="text-white-50">PeTIK Jombang</small>
        </div>
        <hr class="text-white">
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('lecturer.dashboard') }}" class="nav-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.schedules.index') }}" class="nav-link">
                    <i class="bi bi-calendar3 me-2"></i> Jadwal Mengajar
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.attendances.index') }}" class="nav-link">
                    <i class="bi bi-clipboard-check me-2"></i> Presensi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.grades.index') }}" class="nav-link">
                    <i class="bi bi-journal-richtext me-2"></i> Input Nilai
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.materials.index') }}" class="nav-link active">
                    <i class="bi bi-file-earmark-text me-2"></i> Materi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('lecturer.announcements.index') }}" class="nav-link">
                    <i class="bi bi-megaphone me-2"></i> Pengumuman
                </a>
            </li>
        </ul>
        <div class="mt-auto">
            <hr class="text-white">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link btn btn-link text-start w-100">
                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header Section (Responsif untuk teks & button) -->
        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3 mb-4">
            <div>
                <h4 class="fw-bold mb-0">Materi Kuliah</h4>
                <small class="text-muted">Kelola materi perkuliahan</small>
            </div>
            <a href="{{ route('lecturer.materials.create') }}" class="btn btn-success w-100 w-sm-auto py-2">
                <i class="bi bi-plus-circle me-2"></i> Upload Materi
            </a>
        </div>

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <div class="card">
            <div class="card-body p-0">
                <!-- Wrapper Table Responsive agar tabel bisa di-swipe pada layar HP -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="min-width: 800px;">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4" style="width: 70px;">No</th>
                                <th>Mata Kuliah</th>
                                <th>Judul Materi</th>
                                <th>Pertemuan</th>
                                <th>File</th>
                                <th>Tanggal</th>
                                <th class="text-center" style="width: 100px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($materials as $index => $material)
                            <tr>
                                <td class="ps-4">{{ $index + 1 }}</td>
                                <td class="fw-semibold">{{ $material->schedule->course->name }}</td>
                                <td>{{ $material->title }}</td>
                                <td><span class="badge bg-secondary bg-opacity-10 text-secondary">Pertemuan {{ $material->meeting_number }}</span></td>
                                <td>
                                    @if($material->file_path)
                                        <a href="{{ asset('storage/' . $material->file_path) }}" target="_blank" class="btn btn-sm btn-outline-primary text-truncate" style="max-width: 200px;">
                                            <i class="bi bi-download me-1"></i> {{ $material->file_name }}
                                        </a>
                                    @else
                                        <span class="text-muted small">Tidak ada file</span>
                                    @endif
                                </td>
                                <td class="text-muted">{{ $material->created_at->format('d M Y') }}</td>
                                <td class="text-center text-nowrap">
                                    <form action="{{ route('lecturer.materials.destroy', $material->id) }}" method="POST" class="d-inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger px-2" onclick="return confirm('Yakin ingin menghapus materi ini?')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox fs-1 d-block mb-3 text-success"></i>
                                    Belum ada berkas materi yang diupload.
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript Logic untuk Toggle Buka/Tutup Sidebar Mobile
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebarClose = document.getElementById('sidebarClose');
        const sidebarMenu = document.getElementById('sidebarMenu');
        const sidebarBackdrop = document.getElementById('sidebarBackdrop');

        function toggleSidebar() {
            sidebarMenu.classList.toggle('show');
            sidebarBackdrop.classList.toggle('d-none');
        }

        sidebarToggle.addEventListener('click', toggleSidebar);
        sidebarClose.addEventListener('click', toggleSidebar);
        sidebarBackdrop.addEventListener('click', toggleSidebar);
    </script>
</body>
</html>