<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Kuliah - Portal Akademik PeTIK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; }
        
        /* CSS Sidebar Utama (Desktop) */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #4a235a, #7d3c98);
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1030;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 10px;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        /* CSS Konten Utama (Desktop) */
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
            transition: all 0.3s ease;
        }
        
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }

        /* Responsive Breakpoints (Layar HP dan Tablet) */
        @media (max-width: 767.98px) {
            .sidebar {
                left: -250px; /* Sembunyikan sidebar ke kiri */
            }
            .sidebar.show {
                left: 0; /* Tampilkan sidebar ketika aktif */
            }
            .main-content { 
                margin-left: 0; /* Konten memenuhi layar di mobile */
                padding: 20px;
            }
            /* Overlay latar belakang gelap saat sidebar aktif di HP */
            .sidebar-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: rgba(0,0,0,0.4);
                z-index: 1020;
                display: none;
            }
            .sidebar-overlay.show {
                display: block;
            }
        }
    </style>
</head>
<body>

    <!-- Overlay untuk layar mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3" id="sidebarMenu">
        <div class="text-center mb-4 mt-2 position-relative">
            <h5 class="text-white fw-bold m-0">Portal Academic</h5>
            <small class="text-white-50">PeTIK Jombang</small>
            <!-- Tombol close sidebar khusus di HP -->
            <button type="button" class="btn-close btn-close-white d-md-none position-absolute top-0 end-0" id="btnHideSidebar" aria-label="Close"></button>
        </div>
        <hr class="text-white">
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('student.dashboard') }}" class="nav-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.profile') }}" class="nav-link">
                    <i class="bi bi-person-circle me-2"></i> Data Pribadi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.schedules') }}" class="nav-link active">
                    <i class="bi bi-calendar3 me-2"></i> Jadwal Kuliah
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.attendances') }}" class="nav-link">
                    <i class="bi bi-clipboard-check me-2"></i> Presensi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.grades') }}" class="nav-link">
                    <i class="bi bi-journal-richtext me-2"></i> Nilai
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.materials') }}" class="nav-link">
                    <i class="bi bi-file-earmark-text me-2"></i> Materi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.announcements') }}" class="nav-link">
                    <i class="bi bi-megaphone me-2"></i> Pengumuman
                </a>
            </li>
        </ul>
        <div class="mt-auto">
            <hr class="text-white">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link btn btn-link text-start w-100">
                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="d-flex align-items-center gap-3">
                <!-- Tombol Hamburger Menu (Hanya muncul di HP/Tablet) -->
                <button class="btn btn-outline-secondary d-md-none" id="btnToggleSidebar" type="button">
                    <i class="bi bi-list fs-4"></i>
                </button>
                <div>
                    <h4 class="fw-bold mb-0">Jadwal Kuliah</h4>
                    <small class="text-muted">Jadwal perkuliahan semester ini</small>
                </div>
            </div>
        </div>

        @php
            $days = [
                'monday' => 'Senin', 'tuesday' => 'Selasa',
                'wednesday' => 'Rabu', 'thursday' => 'Kamis',
                'friday' => 'Jumat', 'saturday' => 'Sabtu'
            ];
            $dayOrder = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
            $grouped = $schedules->groupBy('day');
        @endphp

        <!-- Grouping Jadwal Per Hari -->
        @forelse($dayOrder as $day)
            @if($grouped->has($day))
            <div class="mb-4">
                <h6 class="fw-bold text-muted mb-3">
                    <i class="bi bi-calendar-day me-2"></i>{{ $days[$day] }}
                </h6>
                <div class="row g-3">
                    @foreach($grouped[$day] as $schedule)
                    <div class="col-md-4">
                        <div class="card p-3 h-100 shadow-sm" style="border-left: 4px solid #7d3c98;">
                            <h6 class="fw-bold mb-1 text-wrap">{{ $schedule->course->name }}</h6>
                            <div class="d-flex flex-column gap-1 mt-2">
                                <small class="text-muted text-break"><i class="bi bi-tag me-1"></i>{{ $schedule->course->code }}</small>
                                <small class="text-muted"><i class="bi bi-clock me-1"></i>{{ \Carbon\Carbon::parse($schedule->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($schedule->end_time)->format('H:i') }}</small>
                                <small class="text-muted text-break"><i class="bi bi-geo-alt me-1"></i>{{ $schedule->room ?? '-' }}</small>
                                <small class="text-muted text-break"><i class="bi bi-person me-1"></i>{{ $schedule->lecturer->name }}</small>
                                <small class="text-muted"><i class="bi bi-layers me-1"></i>{{ $schedule->course->credits }} SKS</small>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif
        @empty
        <div class="card p-5 text-center text-muted">
            <i class="bi bi-inbox fs-1 d-block mb-3"></i>
            <p class="mb-0">Belum ada jadwal kuliah</p>
        </div>
        @endforelse
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript ringkas untuk toggle drawer sidebar di mobile
        const sidebarMenu = document.getElementById('sidebarMenu');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const btnToggleSidebar = document.getElementById('btnToggleSidebar');
        const btnHideSidebar = document.getElementById('btnHideSidebar');

        function toggleSidebar() {
            sidebarMenu.classList.toggle('show');
            sidebarOverlay.classList.toggle('show');
        }

        btnToggleSidebar.addEventListener('click', toggleSidebar);
        btnHideSidebar.addEventListener('click', toggleSidebar);
        sidebarOverlay.addEventListener('click', toggleSidebar);
    </script>
</body>
</html>