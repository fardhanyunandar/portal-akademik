<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengumuman - Portal Academic PeTIK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f0f2f5; }
        
        /* CSS Sidebar Utama (Desktop) */
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, #4a235a, #7d3c98);
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1030;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 10px 20px;
            border-radius: 8px;
            margin: 2px 10px;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        
        /* CSS Konten Utama (Desktop) */
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
            transition: all 0.3s ease;
        }
        
        .card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.08); }

        /* Responsive Breakpoints (Layar HP dan Tablet) */
        @media (max-width: 767.98px) {
            .sidebar {
                left: -250px; /* Menyembunyikan sidebar ke kiri layar mobile */
            }
            .sidebar.show {
                left: 0; /* Menampilkan sidebar saat tombol menu diklik */
            }
            .main-content { 
                margin-left: 0; /* Konten utama penuhi layar di mobile */
                padding: 20px;
            }
            /* Overlay latar belakang gelap saat sidebar aktif di HP */
            .sidebar-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: rgba(0,0,0,0.4);
                z-index: 1020;
                display: none;
            }
            .sidebar-overlay.show {
                display: block;
            }
        }
    </style>
</head>
<body>

    <!-- Overlay untuk layar mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar d-flex flex-column p-3" id="sidebarMenu">
        <div class="text-center mb-4 mt-2 position-relative">
            <h5 class="text-white fw-bold m-0">Portal Akademik</h5>
            <small class="text-white-50">PeTIK Jombang</small>
            <!-- Tombol close sidebar khusus di mobile -->
            <button type="button" class="btn-close btn-close-white d-md-none position-absolute top-0 end-0" id="btnHideSidebar" aria-label="Close"></button>
        </div>
        <hr class="text-white">
        <ul class="nav flex-column gap-1">
            <li class="nav-item">
                <a href="{{ route('student.dashboard') }}" class="nav-link">
                    <i class="bi bi-speedometer2 me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.profile') }}" class="nav-link">
                    <i class="bi bi-person-circle me-2"></i> Data Pribadi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.schedules') }}" class="nav-link">
                    <i class="bi bi-calendar3 me-2"></i> Jadwal Kuliah
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.attendances') }}" class="nav-link">
                    <i class="bi bi-clipboard-check me-2"></i> Presensi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.grades') }}" class="nav-link">
                    <i class="bi bi-journal-richtext me-2"></i> Nilai
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.materials') }}" class="nav-link">
                    <i class="bi bi-file-earmark-text me-2"></i> Materi
                </a>
            </li>
            <li class="nav-item">
                <a href="{{ route('student.announcements') }}" class="nav-link active">
                    <i class="bi bi-megaphone me-2"></i> Pengumuman
                </a>
            </li>
        </ul>
        <div class="mt-auto">
            <hr class="text-white">
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="nav-link btn btn-link text-start w-100">
                    <i class="bi bi-box-arrow-left me-2"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="d-flex align-items-center gap-3">
                <!-- Tombol Hamburger Menu (Hanya muncul di HP/Tablet) -->
                <button class="btn btn-outline-secondary d-md-none" id="btnToggleSidebar" type="button">
                    <i class="bi bi-list fs-4"></i>
                </button>
                <div>
                    <h4 class="fw-bold mb-0">Pengumuman</h4>
                    <small class="text-muted">Pengumuman terbaru untuk mahasantri</small>
                </div>
            </div>
        </div>

        <!-- List Pengumuman -->
        <div class="row g-4">
            @forelse($announcements as $announcement)
            <div class="col-12">
                <div class="card p-4" style="border-left: 4px solid #7d3c98;">
                    <!-- Menggunakan flex column di mobile agar tanggal tidak berhimpitan dengan judul -->
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-1 mb-2">
                        <h5 class="fw-bold mb-0">{{ $announcement->title }}</h5>
                        <small class="text-muted text-nowrap"><i class="bi bi-calendar3 me-1 d-md-none"></i>{{ $announcement->created_at->format('d M Y') }}</small>
                    </div>
                    <p class="text-muted mb-2 small-text" style="text-align: justify;">{{ $announcement->content }}</p>
                    <hr class="my-2 opacity-25">
                    <small class="text-muted d-block">
                        <i class="bi bi-person me-1"></i>Oleh: <strong>{{ $announcement->user->name }}</strong>
                    </small>
                </div>
            </div>
            @empty
            <div class="col-12">
                <div class="card p-5 text-center text-muted">
                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                    <p class="mb-0">Belum ada pengumuman terbaru</p>
                </div>
            </div>
            @endforelse
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript ringkas untuk menghidupkan Drawer Sidebar di Mobile
        const sidebarMenu = document.getElementById('sidebarMenu');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const btnToggleSidebar = document.getElementById('btnToggleSidebar');
        const btnHideSidebar = document.getElementById('btnHideSidebar');

        function toggleSidebar() {
            sidebarMenu.classList.toggle('show');
            sidebarOverlay.classList.toggle('show');
        }

        btnToggleSidebar.addEventListener('click', toggleSidebar);
        btnHideSidebar.addEventListener('click', toggleSidebar);
        sidebarOverlay.addEventListener('click', toggleSidebar);
    </script>
</body>
</html>